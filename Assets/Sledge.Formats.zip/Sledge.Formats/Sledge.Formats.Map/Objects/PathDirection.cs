﻿namespace Sledge.Formats.Map.Objects
{
    public enum PathDirection
    {
        OneWay,
        Circular,
        PingPong
    }
}