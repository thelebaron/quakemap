﻿namespace Sledge.Formats.Map.Objects
{
    public class Worldspawn : Entity
    {
        public Worldspawn()
        {
            ClassName = "worldspawn";
        }
    }
}