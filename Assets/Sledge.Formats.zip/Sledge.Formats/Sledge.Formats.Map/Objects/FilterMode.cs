﻿namespace Sledge.Formats.Map.Objects
{
    public enum FilterMode
    {
        Nearest = 0,
        Linear = 1,
    }
}