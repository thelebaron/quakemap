﻿namespace Sledge.Formats.Map.Objects
{
    public class Group : MapObject
    {

    }
}