namespace Sledge.Formats.Precision
{
    public enum PlaneClassification
    {
        Front,
        Back,
        OnPlane,
        Spanning
    }
}