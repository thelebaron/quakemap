namespace Sledge.Formats.Geometric
{
    public enum PlaneClassification
    {
        Back = -1,
        OnPlane = 0,
        Front = 1,
        Spanning = 2
    }
}